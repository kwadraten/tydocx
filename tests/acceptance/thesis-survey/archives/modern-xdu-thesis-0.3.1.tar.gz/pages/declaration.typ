// 西安电子科技大学硕士学位论文 Typst 模板 — 声明
//
// 依据：docs/前置部分规格.md §4
// - 无页眉、无页脚、无页码；单页容纳两部分：独创性声明 + 使用授权说明
// - 标题：宋体 14pt，居中（两块标题都是 14pt —— 第二块容易漏，注意）
// - 正文：宋体 12pt，固定 20 磅行距，首行缩进 2 字符，两端对齐
// - 签名行：官方带 2 字符缩进（墨迹起点 38.47mm），0.4pt **实线**、宽 34.73mm
//   本人签名：38.47 起 / 线 59.64~94.37 ；日期：124.44 起 / 线 146.04~180.77

#import "../layouts/doc.typ": 基线偏移, 到内容区, 页面坐标
#import "../utils/style.typ": 字体 as 字体集

#let 正文Δ = 基线偏移(20pt, 12pt)
#let 正文隙 = 20pt - 正文Δ
#let 标题14Δ = 基线偏移(20pt, 14pt)
// 填空横线按官方 templet.pdf 使用连续 0.4pt 实线。
#let 填空线样式 = 0.4pt

// 声明正文段落（官方原文）
#let 声明正文 = (
  "秉承学校严谨的学风和优良的科学道德，本人声明所呈交的论文是我个人在导师指导下进行的研究工作及取得的研究成果。尽我所知，除了文中特别加以标注和致谢中所罗列的内容以外，论文中不包含其他人已经发表或撰写过的研究成果；也不包含为获得西安电子科技大学或其它教育机构的学位或证书而使用过的材料。与我一同工作的同事对本研究所做的任何贡献均已在论文中作了明确的说明并表示了谢意。",
  "学位论文若有不实之处，本人承担一切法律责任。",
)

#let 授权正文 = (
  "本人完全了解西安电子科技大学有关保留和使用学位论文的规定，即：研究生在校攻读学位期间论文工作的知识产权属于西安电子科技大学。学校有权保留送交论文的复印件，允许查阅、借阅论文；学校可以公布论文的全部或部分内容，允许采用影印、缩印或其它复制手段保存论文。同时本人保证，结合学位论文研究成果完成的论文、发明专利等成果，署名单位为西安电子科技大学。",
  "保密的学位论文在　　　　年解密后适用本授权书。",
)

#let declaration(
  degree: "academic",
  blind: false,
  fonts: (:),
  info: (:),
) = {
  let 字体集 = 字体集 + fonts
  set page(header: none, footer: none, numbering: none)

  // 居中标题（宋体 14pt）
  let 居中标题(文字, 基线y) = place(top + left, dx: 30mm, dy: 到内容区(基线y) - 标题14Δ,
    box(width: 155mm, align(center, {
      set text(font: 字体集.宋体, size: 14pt, lang: "zh",
        top-edge: 标题14Δ, bottom-edge: "baseline")
      文字
    })))

  // 正文段落块（宋体 12pt，固定 20 磅，首行缩进 2 字符）
  let 正文块(段落, 基线y) = place(top + left, dx: 30mm, dy: 到内容区(基线y) - 正文Δ,
    box(width: 155mm, par(
      leading: 正文隙, spacing: 正文隙, justify: true, first-line-indent: (amount: 2em, all: true),
      text(font: 字体集.宋体, size: 12pt, lang: "zh",
        top-edge: 正文Δ, bottom-edge: "baseline", 段落),
    )))

  // 签名行：官方带 2 字符缩进（38.47mm 起），填空线宽 34.73mm
  let 签名行(基线y, 左标签, 右标签) = {
    let y = 到内容区(基线y)
    place(top + left, dx: 38.47mm, dy: y - 正文Δ, box({
      set text(font: 字体集.宋体, size: 12pt, lang: "zh",
        top-edge: 正文Δ, bottom-edge: "baseline")
      左标签
    }))
    place(top + left, dx: 59.64mm, dy: y + 1.06mm,
      line(length: 34.73mm, stroke: 填空线样式))
    place(top + left, dx: 124.44mm, dy: y - 正文Δ, box({
      set text(font: 字体集.宋体, size: 12pt, lang: "zh",
        top-edge: 正文Δ, bottom-edge: "baseline")
      右标签
    }))
    place(top + left, dx: 146.04mm, dy: y + 1.06mm,
      line(length: 34.73mm, stroke: 填空线样式))
  }

  // 整页用页面绝对坐标（见 doc.typ 的 页面坐标）
  页面坐标({
    // ---- 独创性声明 ----
    居中标题("西安电子科技大学", 35.11mm)
    居中标题("学位论文独创性（或创新性）声明", 42.14mm)
    正文块(声明正文.at(0), 53.74mm)
    // 第二段：官方实测在首段末行之后（基线 95.92mm）
    正文块(声明正文.at(1), 95.92mm)
    签名行(109.97mm, "本人签名：", "日期：")

    // ---- 使用授权说明 ----
    居中标题("西安电子科技大学", 178.53mm)
    居中标题("关于论文使用授权的说明", 185.55mm)
    正文块(授权正文.at(0), 197.15mm)
    正文块(授权正文.at(1), 232.30mm)
    签名行(246.36mm, "本人签名：", "导师签名：")
    签名行(260.42mm, "日期：", "日期：")
  })
}
