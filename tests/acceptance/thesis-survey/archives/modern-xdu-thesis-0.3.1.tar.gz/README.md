# 西安电子科技大学学位论文 Typst 模板

用 [Typst](https://typst.app) 排版西安电子科技大学本科毕业设计（论文）、硕士与博士学位论文
（中文撰写），并提供研究生/本科开题、中期考核和通用课程实验报告入口。论文与行政表使用
独立入口；`typst init` 的默认模板仍为硕士。

**本模板不是学校官方发布**，版式数值以学校发布的 Word / LaTeX 模板及配套规范为准；与官方模板存在差异的地方
逐条列在[「与官方模板的差异」](#与官方模板的差异)。

| 硕士（学术 / 专业学位） | 本科毕业设计（论文） |
|---|---|
| ![硕士预览：封面 / 目录 / 正文](https://raw.githubusercontent.com/CoderJackZhu/modern-xdu-thesis/053e54ad89df3c4ef4008435e24f7650d97c8f00/docs/images/preview.png) | ![本科预览：封面 / 目录 / 正文](https://raw.githubusercontent.com/CoderJackZhu/modern-xdu-thesis/053e54ad89df3c4ef4008435e24f7650d97c8f00/docs/images/preview-bachelor.png) |

## 特性

- **本科与研究生独立版式**：本科使用 150 × 247mm 版心、1.5 倍行距、页眉外侧页码与 0.75 磅单线；硕士/博士保留 155 × 240.93mm 版心、固定 20 磅行距、页脚页码与双横线。
- **学术学位 / 专业学位**：一个参数切换，差异只在封面与题名页的字段。
- **研究生盲审模式**：一个开关隐去封面、题名页与作者简介中的身份信息。
- **图表公式自动编号**：按章编号（图 2.1 / 表 2.1 / 式 (2-1)），插图索引、表格索引、
  目录自动生成，交叉引用直接写 `@标签`。
- **参考文献**：GB/T 7714-2015，写作样式由 Typst 内置引擎完成；中文文献「等」与英文文献
  「et al.」自动区分。
- **不依赖额外字体**：全篇只用宋体、黑体、Times New Roman，按系统字体解析，不内置字体文件。

## 包含与不包含

| 范围 | 说明 |
|---|---|
| 硕士学位论文（中文撰写） | 包含：封面、中英文题名页、声明、中英文摘要、插图索引、表格索引、符号对照表、缩略语对照表、目录、正文、附录、参考文献、致谢、作者简介 |
| 学术学位 / 专业学位 | 包含：由一个参数切换 |
| 盲审模式 | 包含：由一个开关控制 |
| 本科毕业设计（论文） | 包含：可开关封面、中英文摘要、目录、正文、附录、参考文献、致谢；独立 `bachelor` 入口 |
| 本科装订独立表单 | 包含：开题报告、中期报告；不包含：诚信书、任务书、周记、中期检查表、成绩评定表、查重报告等仍以学院/本科生院原表为准 |
| 博士学位论文（中文撰写） | 包含：博士专用封面、中英文题名页，学术博士与专业博士字段；正文及后置部分沿用研究生模板 |
| 研究生开题 / 中期 | 包含：学术/专业硕士、学术/专业博士四类；学院流程和系统导出件仍以学院通知为准 |
| 课程实验报告 | 包含：通用骨架；非全校统一模板，教师指定模板优先 |
| 英文撰写的学位论文 | 不包含 |
| 科研实验记录本 | 不包含：未找到全校统一版式，采用学院或导师提供的本子/表格 |
| 答辩、评阅、审批、经费等表格 | 不包含：只保留官方链接，不批量复刻 |
| 详细中文摘要（单独装订） | 不包含：学校规定与论文分开装订 |

## 环境要求

- **Typst 0.15** 或更高版本。安装方式二选一：
  - **编辑器插件（推荐）**：VS Code / Cursor 安装 [Tinymist Typst](https://marketplace.visualstudio.com/items?itemName=myriad-dreamin.tinymist)，
    打开 `.typ` 文件即可实时预览，插件自带编译器。
  - **命令行**：`brew install typst`（macOS）、`winget install --id Typst.Typst`（Windows），
    或参考 [官方安装说明](https://github.com/typst/typst#installation)。
- **字体**：系统自带即可。Windows 的 `SimSun` / `SimHei`，macOS 的 `Songti SC` / `Heiti SC`，
  Linux 安装 `fonts-noto-cjk`。模板不内置字体文件。

## 快速开始

当前版本为 `0.3.1`。Universe 收录进度以 [包页面](https://typst.app/universe/package/modern-xdu-thesis)
和 [版本提交记录](https://github.com/typst/packages/pulls?q=is%3Apr+modern-xdu-thesis) 为准。
如果新版本尚未收录，请先按下方步骤注册本地包；新版本可用后，一条命令即可创建项目：

```bash
typst init @preview/modern-xdu-thesis:0.3.1 my-thesis   # 硕士（默认模板）
cd my-thesis && typst compile thesis.typ                # 编译出 PDF
```

本科没有 `[template]` 入口（一个包只能声明一份默认模板，已留给硕士），
把 [`examples/bachelor-thesis.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/bachelor-thesis.typ)
复制到自己的项目后编译即可。

`0.3.1` 修正发布包 README 的跨版本链接并保留 `0.3.0` 的全部功能：研究生/本科开题、
中期考核、通用课程实验报告，以及 `0.2.0` 的博士支持与本科学位论文格式修正。
博士没有默认 `[template]` 入口，
从包导入 `doctor-documentclass`（本地源码也可导入 `doctor.typ` 的 `documentclass`），完整示例见
[`examples/doctor-thesis.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/doctor-thesis.typ)：

```typst
#import "@preview/modern-xdu-thesis:0.3.1": doctor-documentclass
#let thesis = doctor-documentclass(
  degree: "professional",             // academic / professional
  blind: false,
  info: (
    degree-name: "工程博士",
    degree-name-en: "Doctor of Engineering",
    category-en: "Electronic Information",
    // 其余字段同硕士；专业博士的企业导师中英文须同时填写或同时省略
  ),
)
#show: thesis.doc
#(thesis.cover)()
```

想直接使用仓库源码（Universe 尚未收录新版本时也适用）：

```bash
git clone https://github.com/CoderJackZhu/modern-xdu-thesis
cd modern-xdu-thesis
bash dev/pkg-stage.sh                          # 把本仓库注册为本地 Typst 包，只需运行一次
typst compile --root . template/thesis.typ out.pdf               # 硕士默认模板
typst compile --root . examples/bachelor-thesis.typ bachelor.pdf # 本科独立示例
typst compile --root . examples/doctor-thesis.typ doctor.pdf     # 学术博士
typst compile --root . --input degree=professional examples/doctor-thesis.typ doctor-pro.pdf
```

博士示例使用 `examples/doctor-ref.bib`，包外使用时将两个文件一起复制到项目。
也可直接调用 `documentclass(graduate: "doctor", ...)`。博士默认学位名为工学博士 /
Doctor of Philosophy（学术）、工程博士 / Doctor of Engineering（专业），请按实际学位覆盖。
专业博士的 `category-en` 是学位类别英文，学术博士用 `discipline-en`；
`domain` 仍用于中文题名页的领域。

博士前置页按官方 Word 的原始文本框锚点重建，主体沿用研究生排版；来源、
字段与验收边界见 [博士规格](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/博士规格.md)。尚未经过原生 Word 逐像素比对或学校格式检测。
与 Hubert9982 本科模板的对比和本次三项修正见 [本科模板对比](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/本科模板对比.md)。
另已抽查六份公开成品（本科、硕士、博士各两份），包括李瑞远2020年158页博士论文；
来源、文件指纹、测量结果及历史版本差异见 [公开成品交叉核对](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/公开成品交叉核对.md)。
专业博士2026.5专用前置页的公开成品尚未取得，当前依据仍为官网原始Word。
本次变更及发布步骤见 [发布说明](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/发布说明.md)。

### 开题、中期与课程实验报告

配套材料不是学位论文正文，使用独立入口，且不改变论文的默认 `[template]`。完整示例：

- [`examples/proposal-thesis.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/proposal-thesis.typ)
  —— 研究生开题报告，支持 `--input graduate=doctor --input degree=professional`
- [`examples/interim-thesis.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/interim-thesis.typ)
  —— 研究生中期考核报告
- [`examples/bachelor-proposal.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/bachelor-proposal.typ)
  —— 本科开题报告
- [`examples/bachelor-interim.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/bachelor-interim.typ)
  —— 本科中期报告
- [`examples/course-report.typ`](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/examples/course-report.typ)
  —— 通用课程实验报告

```typst
#import "@preview/modern-xdu-thesis:0.3.1": proposal-documentclass
#let (doc, proposal) = proposal-documentclass(
  graduate: "doctor",
  degree: "professional",
  info: (
    title: ("题目第一行", "题目第二行"),
    author: "张三",
    student-id: "2026000001",
    department: "电子工程学院",
    degree-name: "工程博士",
    domain: "电子信息",
    supervisor: "李四　教授",
    enterprise-supervisor: "王五　高级工程师",
    proposal-date: "2026 年 10 月",
  ),
)
#show: doc
#proposal(body: (
  topicSource: [选题来源],
  abstract: [中文摘要],
  significance: [选题意义],
  researchStatus: [国内外研究现状],
  goal: [研究目标],
  researchContent: [研究内容],
  keyProblems: [拟解决的关键问题],
  methods: [研究方法、技术路线和可行性],
  innovation: [论文创新点],
  plan: [研究计划和预期成果],
  foundation: [实验条件和研究积累],
  achievements: [已取得成果],
  record: [开题报告记录],
  rubric: ("论文选题": "良好", "研究方案": "良好", "研究基础": "合格", "进度安排": "良好"),
  conclusion: [评语及结论],
  advisorOpinion: [指导教师意见],
))
```

表格依据、字段差异和已知限制见
[配套材料规格](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/配套材料规格.md) 与
[配套材料导航](https://github.com/CoderJackZhu/modern-xdu-thesis/blob/v0.3.1/docs/配套材料导航.md)。
开题/中期原表要求 A3 正反套印，本包输出 A4 单页；
学校研究生管理系统、学院签批和最终格式检测仍需按当期通知完成。课程实验报告入口不是学校
官方模板，教师已给出模板时应直接使用教师模板。

`dev/pkg-stage.sh` 把仓库挂到 Typst 的本地包目录，模板里的
`@preview/modern-xdu-thesis:0.3.1` 才能解析到当前工作区。脚本可重复运行，解除用
`bash dev/pkg-stage.sh --remove`。

### 在线编辑（typst.app）

把项目上传到 [Typst Web App](https://typst.app) 即可在线编辑、多人协作，不必安装任何东西。
**但 Web App 没有本机字体**：需要把宋体、黑体、Times New Roman 的字体文件一并上传到项目里
（Windows 在 `C:\Windows\Fonts`，macOS 在 `/System/Library/Fonts` 与 `/Library/Fonts`），
否则正文会显示成方框（豆腐块）。字体有版权，仅供自己项目内使用。

### 本科独立入口

`typst.toml` 的 `[template]` 仍指向硕士 `template/thesis.typ`。本科从包导出的独立
`bachelor` 模块进入，完整文件见 `examples/bachelor-thesis.typ`：

学校官方校名标准字与校徽的再分发条款不可得，因此**本包不附带这两项标识素材**。请从
[教务处官方下载页](https://jwc.xidian.edu.cn/info/1022/12943.htm)获取，或直接下载
[`毕业设计表格-全套.zip`](https://jwc.xidian.edu.cn/system/_content/download.jsp?urltype=news.DownloadAttachUrl&owner=1070628979&wbfileid=B32886C694EC6AD523FA1277D0C25409)。
若直链失效，请回到官方下载页，下载名为 `毕业设计表格-全套.zip` 的附件。

解压外层文件 `毕业设计表格-全套.zip`，找到内层文件
`1-1.西安电子科技大学本科毕业设计（论文）封皮模板（需装订）.docx`；将该 DOCX 打开为 ZIP
（或把扩展名改为 `.zip` 后解压），取出 `word/media/image1.jpeg`（中文校名标准字）和
`word/media/image2.png`（校徽），分别放到自己项目的 `assets/xdu-wordmark.jpeg` 与
`assets/xdu-emblem.png`。然后用调用方构造的 `path(...)` 传给模板：

```typ
#import "@preview/modern-xdu-thesis:0.3.1": bachelor

#let (doc, cover, abstract, abstract-en, outline-page, mainmatter,
  appendix, references, acknowledgement) = bachelor.documentclass(
  cover-wordmark: path("assets/xdu-wordmark.jpeg"),
  cover-emblem: path("assets/xdu-emblem.png"),
  cover-enabled: true, // 学院封面不同时可设为 false，再自行插入封面
  info: (
    title: ("论文题目第一行", "论文题目第二行"),
    author: "张三",
    department: "电子工程学院",
    major: "电子信息工程",
    supervisor: ("李四", "王五"),
    class-id: "2101011",
    student-id: "21010100001",
    abstract: [这里填写中文摘要。],
    abstract-en: [English abstract...],
    keywords: ("关键词一", "关键词二", "关键词三"),
    keywords-en: ("keyword one", "keyword two", "keyword three"),
  ),
)
```

未传入某项素材时，对应位置会显示浅灰色占位框，位置和尺寸不变：校名标准字区域为
64.5 × 12.04mm，校徽区域为 42.1mm 正方形。也可以在单次调用时覆盖，例如
`#cover(cover-wordmark: path("assets/xdu-wordmark.jpeg"), cover-emblem: path("assets/xdu-emblem.png"))`。

`info` 字段与硕士基本对应，本科特有的三项：

| 字段 | 说明 |
|---|---|
| `title` | 题目，多行写成数组 `("第一行", "第二行")`，居中排在封面横线上 |
| `class-id` / `student-id` | 班级 / 学号，排在封面右上角 |
| `supervisor` | 导师，可写两人 `("李四", "王五")` |

其余字段（`author`、`department`、`major`、`abstract`、`abstract-en`、`keywords`、
`keywords-en`）与硕士含义相同。`cover-enabled: false` 时封面整页不输出，也不会显示占位符，
可改为插入学院提供的官方封面。

本科正文一级标题只写 `= 引言`，模板自动生成“第一章 引言”；附录连续调用
`appendix(...)`，会生成“附录 A / B / C”及图 A1、表 B2、式 (C-3)。

## 硕士配置论文信息

打开 `template/thesis.typ`，把 `documentclass(...)` 里的 `info` 换成你自己的信息：

| 字段 | 说明 |
|---|---|
| `title` / `title-en` | 中英文题目，多行写成数组 `("第一行", "第二行")` |
| `author` / `author-en` | 姓名 / 拼音 |
| `discipline` / `subdiscipline` | 一级学科 / 二级学科（学术学位） |
| `domain` | 领域（专业学位） |
| `degree-name` | 学位名称，如 `"电子信息硕士"` |
| `supervisor` | 导师，`("李四", "教授")` |
| `enterprise-supervisor` | 企业导师，仅专业学位使用；学术学位填 `(none, none)` |
| `department` | 学院 |
| `submit-date` | 提交日期，`(year: 2025, month: 6)` |
| `school-code` / `clc` / `student-id` / `secret-level` | 题名页左上角信息栏（西电代码 `10701`） |
| `abstract` / `keywords` | 中文摘要与关键词 |
| `abstract-en` / `keywords-en` | 英文摘要与关键词 |
| `notation` | 符号对照表，如 `(("α", "路径损耗指数"), ("β", "衰减系数"))` |
| `abbreviations` | 缩略语对照表，如 `(("MIMO", "Multiple-Input Multiple-Output", "多输入多输出"),)` |

硕士 `author` 可用 `[自定义内容]` 显示富文本。PDF Author 仅接收字符串或字符串数组；
其他类型的作者内容不写入元数据。`blind: true` 时 Author 留空，中文题名页的学号也隐藏。

关键词写成数组，模板会按「逗号 + 空格」分隔并处理末尾标点。

## 写作指南

> 学校对论文各部分的具体规定（题目字数、摘要篇幅、关键词个数、图表公式写法、参考文献数量、
> 作者简介要求、装订顺序、盲审注意事项等），以及**哪些由模板自动满足、哪些必须自己保证**，
> 见 [写作要求](写作要求.md)。提交前可对照其中的自查清单逐项检查。

### 硕士页面顺序

前置与后置部分按下面的顺序调用，页与页之间用 `#pagebreak(to: "odd")` 分隔，
使每页都从奇数页开始：

```typ
#show: doc

#cover()
#pagebreak(to: "odd")
#title-cn()                     // 中文题名页
#pagebreak(to: "odd")
#title-en()                     // 英文题名页
#pagebreak(to: "odd")
#declaration()                  // 声明
#pagebreak(to: "odd")
#abstract()                     // 中文摘要（罗马页码从这一页起为 I）
#pagebreak(to: "odd")
#abstract-en()                  // ABSTRACT
#pagebreak(to: "odd")
#list-of-figures()              // 插图索引
#pagebreak(to: "odd")
#list-of-tables()               // 表格索引
#pagebreak(to: "odd")
#notation()                     // 符号对照表
#pagebreak(to: "odd")
#abbreviations()                // 缩略语对照表
#pagebreak(to: "odd")
#outline-page()                 // 目录

#show: mainmatter.with(header-title: "西安电子科技大学硕士学位论文")

= 第一章 绪论
这里填写正文内容。

#pagebreak(to: "odd")
#appendix()                     // 附录
#pagebreak(to: "odd")
#references()                   // 参考文献
#pagebreak(to: "odd")
#acknowledgement()              // 致谢
#pagebreak(to: "odd")
#bio()                          // 作者简介
```

`template/thesis.typ` 就是一份可运行的完整示例，直接改它即可。

### 本科页面顺序

```typ
#show: doc
#cover()
#pagebreak(to: "odd")
#counter(page).update(1) // 中文摘要从 i 开始；必须放在摘要页面之前
#abstract()
#pagebreak(to: "odd")
#abstract-en()
#pagebreak(to: "odd")
#outline-page()

#show: mainmatter
= 引言
这里填写正文内容。

#pagebreak(to: "odd")
#acknowledgement()
#pagebreak(to: "odd")
#references(entries: ("作者. 题名[M]. 北京: 出版社, 1993.",))
#pagebreak(to: "odd")
#appendix(title: "补充材料", body: [这里填写附录内容。])
```

封面默认输出并自动留空背面；未配置学校标识时显示固定尺寸的浅灰色占位框。
`cover-enabled: false` 时 `cover()` 不输出内容，可插入学院提供的官方封面。
完整示例见 `examples/bachelor-thesis.typ`。

### 标题

编号由模板生成，正文里不要手写数字：

```typ
= 第一章 绪论          // 章号写在标题文字里
== 研究背景与意义       // 自动编号 1.1
=== 毫米波信道特性      // 自动编号 1.1.1
==== 路径损耗模型       // 自动编号（1），不进目录
```

上例是硕士写法。本科一级标题写 `= 绪论`，由 `bachelor` 入口自动补“第一章”。

### 图、表与公式

```typ
#figure(image("fig.png", width: 80%),
  caption: [毫米波大规模 MIMO 系统框图])      // 图题在下，编号「图 2.1」

#figure(table(columns: 3, [参数], [符号], [取值], [载波频率], [$f_c$], [28 GHz]),
  caption: [仿真参数设置])                    // 表题在上，「表 2.1」

$ bold(y) = bold(A) bold(h) + bold(n) $       // 公式编号「(2-1)」，右对齐
```

图、表、公式按章编号，正文中引用写 `@标签`。题注里可以正常引用文献，
插图索引与表格索引不会因此打乱参考文献的编号顺序。

需要让索引里显示更短的文字时（相当于 LaTeX 的 `\caption[短]{长}`），用 `索引题注`：

```typ
#figure(rect(width: 5cm, height: 2.5cm),
  caption: 索引题注([系统框图], [毫米波大规模 MIMO 系统框图 @zhang2023]))
```

### 参考文献

标准为 GB/T 7714-2015。把文献写进 `.bib` 文件，正文用 `#cite(<条目键>)` 引用，
末尾在**论文文件里**构造好 bibliography，再交给 `#references`：

```typ
正文中的引用示例 #cite(<koseki2002>)。 // 输出上标 [1]

#references(body: bibliography(
  "/refs.bib", style: "gb-7714-2015-numeric", title: none,
))
```

硕士和本科的 `references` 均只提供 `body:` 和 `entries:` 两种文献输入，不接受 `bib:`。
在论文文件里构造 `bibliography`，相对路径按该文件所在目录解析；上例带 `/` 的路径按项目根解析。

也可以直接把排好的条目交给模板：

```typ
#references(entries: (
  "作者甲. 题名[M]. 北京: 出版社, 1993.",
  "作者乙. 题名[J]. 期刊, 2024, 1(1): 1-10.",
))
```

### 盲审模式

`documentclass(blind: true)` 即可。封面与中英文题名页隐去作者与导师姓名；致谢只保留标题；
中文题名页不显示学号；PDF 的 Author 属性留空（否则打开文件属性就能看到作者是谁）；
作者简介中的本文作者姓名替换为「（盲审隐去）」，**保留「第一作者」「第一发明人」等排序标记**，
合作者署名按惯例保留。

`author` 写成字符串或字符串数组时，模板写入 PDF Author 属性；写成 markup（如 `[自定义内容]`）
时，富文本只用于页面显示，不写入元数据（PDF 的 Author 只接受字符串）。若你在 `author` 里自行
拼了身份信息，`blind: true` 只会跳过元数据与姓名栏，正文里自己写的内容仍需自行处理。

## 常见问题

**编译时提示 `unknown font family: simsun` 之类的警告？**
是字体回退链里本机没有的候选字体，属正常提示。只要正文没有出现方框（豆腐块）就不用处理。

**中文显示成方框？**
系统缺少中文字体。按上面的「环境要求」安装对应字体后重新编译。

**参考文献列表是空的？**
正文里没有用 `#cite(<条目键>)` 引用过文献。参考文献只收录被引用过的条目。

**我不会 Typst，能直接用来写论文吗？**
可以。日常使用只涉及「填字段」与「写标题正文」，`.bib` 之外几乎不需要语法知识。
语法参考 [Typst 中文文档](https://typst-doc-cn.github.io/docs/)。

**怎么换成专业学位 / 学术学位？**
改 `degree` 参数。专业学位记得填 `enterprise-supervisor`，学术学位填 `(none, none)`。

**页数和 Word 排出来的不一样？**
字体度量不同会导致换行位置有细微差异，可能相差一两页，属正常现象。

**能改字体或字号吗？**
可以但不建议，学校格式检查会核对字体名。字体映射在 `utils/style.typ`，
版式常量在 `layouts/doc.typ`，修改后请对照官方模板核对版式。

## 与官方模板的差异

| 项 | 说明 |
|---|---|
| 逐行位置 | 字体度量不同导致换行点漂移，不能逐行对齐；固定行距、版心和标题按规格测量，LaTeX与Typst的磅值换算亦有微差 |
| 研究生页眉与页码 | 当前页眉基线比2024.04官方PDF及李瑞远2020成品高约0.88mm，双线高约0.44mm；页码低约1.21mm，与既有过检论文及两份2026硕士成品一致。数值与裁定见格式规格及公开成品报告 |
| 封面与声明 | 官方 LaTeX 模板有两代实现（2024.04 与新版重写版），本模板采用 2024.04 版与 Word 2025.01 版 |
| 博士前置页 | 学术按Word 2025.01、专业按专用Word 2026.5锚点重建；历史博士成品的位置存在版本差异，未作原生Word像素级验收 |
| 符号对照表字号 | 本模板按《撰写要求》采用 12pt；官方 LaTeX 示例未包含此页 |
| 附录页 | 官方示例未包含附录页，其坐标按其它后置部分的统一规则处理 |
| 本科封面标识 | 校名标准字与校徽在官方封面里是图形（无文字层）；因官方再分发条款不可得，本包不附带素材，用户可通过 `cover-wordmark` / `cover-emblem` 提供，未提供时显示固定尺寸占位框 |

## 目录结构

```text
lib.typ          硕士/博士共用入口，导出 doctor-documentclass 与 bachelor 命名空间
doctor.typ       博士独立入口，导出 documentclass
bachelor.typ     本科独立实现入口，bachelor.documentclass(info:, cover-enabled:, cover-wordmark:, cover-emblem:)
bachelor/        本科专用版式、页面与正文规则（不导入硕士 layouts/pages）
supporting/      开题、中期、课程实验报告的独立版式与入口
layouts/         研究生页面版式核心
pages/           研究生页面组件及博士专用前置页
utils/           字体映射与无状态共用工具
template/        硕士示例，也是 typst init 默认复制的目录
examples/        论文、开题、中期、课程实验报告完整示例（博士配套 doctor-ref.bib）
写作要求.md       官方撰写要求对照表 + 提交前自查清单
dev/             仓库开发与验收工具（不进发布包）
docs/            格式规格、官方要求摘录与实现说明（不进发布包）
```

硕士从 `template/thesis.typ` 开始；本科复制 `examples/bachelor-thesis.typ`；
博士复制 `examples/doctor-thesis.typ` 与 `examples/doctor-ref.bib`；
开题/中期/课程实验报告从 `examples/` 下对应文件复制并按学院原表核对。

## 参考资料

- 西安电子科技大学《毕业设计手册》2019 与教务处优秀毕业设计（论文）Word 样例
- 西安电子科技大学研究生院《研究生学位论文模板（2015 年修订版）2025.01 修订》及配套《撰写要求》
- 研究生院学术博士2025.01资料包、专业博士2026.09资料包及其中的2026.5专用前置页
- [xduts](https://github.com/note286/xduts) —— 官网推荐的社区 LaTeX 实现参照
- [modern-nju-thesis](https://github.com/nju-lug/modern-nju-thesis) —— 本模板的初始骨架（MIT）

## 反馈与许可

排版问题、版式差异请走 [Issues](https://github.com/CoderJackZhu/modern-xdu-thesis/issues)。
报版式差异时请附上学校官方模板或规范的对应页，以便按同一依据复核。

代码以 MIT 许可发布。学校官方校名标准字与校徽不在本仓库或软件包内分发；用户应从学校官方
附件取得，并自行确认其使用范围。
