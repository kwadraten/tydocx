#import "droplet.typ": dropcap
