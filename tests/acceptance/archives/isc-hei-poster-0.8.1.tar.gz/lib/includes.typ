// Fancy pretty print with line numbers and stuff
#import "@preview/codelst:2.0.2": sourcecode

// Nice color boxes
#import "@preview/showybox:2.0.4": showybox

// Custom date format
#import "@preview/datify:1.0.1": custom-date-format

#let global-language = state("ln", "en")
#let global-keywords = state("kw", ())
#let header-footers-enabled = state("hf-en", false)
#let global-project-repos = state("repos", none)
#let blank-page = state("blank-page", false)
#let show-toc-enabled = state("show-toc", true)

// Metadata forwarded from project() to the declaration-of-honour page so it
// can auto-fill its identity fields and render the (mandatory) signature image.
#let global-thesis-meta = state("thesis-meta", (:))

// Brand color
#let hei-purple = rgb("#dc0068")