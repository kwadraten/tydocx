#import "@preview/great-theorems:0.1.2": great-theorems-init, mathblock, proofblock
#import "@preview/rich-counters:0.2.2": rich-counter
#import "@preview/i-figured:0.2.4": reset-counters, show-equation

// Language support
#let language-translations = state(
  "language-translations",
  (
    en: (
      "theorem": "Theorem",
      "proposition": "Proposition",
      "corollary": "Corollary",
      "lemma": "Lemma",
      "definition": "Definition",
      "remark": "Remark",
      "example": "Example",
      "question": "Question",
      "proof": "Proof",
      "proof-of": "Proof of",
      "keywords": "Keywords",
      "ams": "AMS subject classification",
      "appendix": "Appendix",
      "abstract": "Abstract",
    ),
    de: (
      "theorem": "Satz",
      "proposition": "Proposition",
      "corollary": "Korollar",
      "lemma": "Lemma",
      "definition": "Definition",
      "remark": "Anmerkung",
      "example": "Beispiel",
      "question": "Frage",
      "proof": "Beweis",
      "proof-of": "Beweis von",
      "keywords": "Schlüsselwörter",
      "ams": "AMS-Klassifikation",
      "appendix": "Anhang",
      "abstract": "Zusammenfassung",
    ),
    fr: (
      "theorem": "Théorème",
      "proposition": "Proposition",
      "corollary": "Corollaire",
      "lemma": "Lemme",
      "definition": "Définition",
      "remark": "Remarque",
      "example": "Exemple",
      "question": "Question",
      "proof": "Preuve",
      "proof-of": "Preuve de",
      "keywords": "Mots clés",
      "ams": "Classification AMS",
      "appendix": "Annexe",
      "abstract": "Résumé",
    ),
    es: (
      "theorem": "Teorema",
      "proposition": "Proposición",
      "corollary": "Corolario",
      "lemma": "Lema",
      "definition": "Definición",
      "remark": "Comentario",
      "example": "Ejemplo",
      "question": "Pregunta",
      "proof": "Demostración",
      "proof-of": "Demostración de",
      "keywords": "Palabras clave",
      "ams": "Clasificación AMS",
      "appendix": "Apéndice",
      "abstract": "Resumen",
    ),
  ),
)

#let get-language-title(label) = {
  context {
    let language = str(text.lang)
    let translations = language-translations.get()
    if language in translations {
      translations.at(language).at(label, default: "Unknown")
    } else {
      translations.en.at(label, default: "Unknown")
    }
  }
}

// counter for mathblocks
#let theoremcounter = rich-counter(
  identifier: "mathblocks",
  inherited_levels: 1,
)

#let my-mathblock = mathblock.with(
  counter: theoremcounter,
  breakable: false,
  titlix: title => [(#title):],
  // suffix: [#h(1fr) $triangle.r$],
)

// theorem etc. settings
#let theorem = my-mathblock(
  blocktitle: get-language-title("theorem"),
  bodyfmt: text.with(style: "italic"),
)

#let proposition = my-mathblock(
  blocktitle: get-language-title("proposition"),
  bodyfmt: text.with(style: "italic"),
)

#let corollary = my-mathblock(
  blocktitle: get-language-title("corollary"),
  bodyfmt: text.with(style: "italic"),
)

#let lemma = my-mathblock(
  blocktitle: get-language-title("lemma"),
  bodyfmt: text.with(style: "italic"),
)

#let definition = my-mathblock(
  blocktitle: get-language-title("definition"),
  bodyfmt: text.with(style: "italic"),
)

#let remark = my-mathblock(blocktitle: [_#get-language-title("remark")_])

#let example = my-mathblock(blocktitle: [_#get-language-title("example")_])

#let question = my-mathblock(blocktitle: [_#get-language-title("question")_])

#let proof = proofblock(prefix: [_#get-language-title("proof")._], prefix_with_of: of => text(style: "oblique", [#get-language-title("proof-of") #of.]))

// To also handle content (e.g. something like $dagger$) as affiliation-id,
// cf. https://github.com/typst/typst/issues/2196#issuecomment-1728135476
#let to-string(content) = {
  if type(content) in (int, float, decimal, version, bytes, label, type, str) {
    str(content)
  } else {
    if content.has("text") {
      content.text
    } else if content.has("children") {
      content.children.map(to-string).join("")
    } else if content.has("body") {
      to-string(content.body)
    } else if content == [ ] {
      " "
    }
  }
}

// Resolve the `affiliation-id`s of an author (a single id or several ids
// separated by commas) to the corresponding names in `affiliations`.
// Ids without a matching affiliation are ignored.
#let affiliations-of(author, affiliations) = {
  if affiliations == none {
    return ()
  }
  let ids = to-string(author.at("affiliation-id", default: ""))
    .split(",")
    .map(id => id.trim())
    .filter(id => id != "")
  ids
    .map(id => affiliations.find(affiliation => to-string(affiliation.at("id", default: "")) == id))
    .filter(affiliation => affiliation != none)
    .map(affiliation => affiliation.name)
}

#let page-args = (
  margin: (left: 25mm, right: 25mm, top: 25mm, bottom: 30mm),
  numbering: "1",
  number-align: center,
)
#let text-args-title = (fill: auto, size: 1.75em,)
#let text-args-authors = (weight: "bold",)

#let template(
  title: "",
  authors: (),
  affiliations: (),
  authors-style: "shared",
  authors-per-row: 3,
  date: datetime.today().display(),
  abstract: none,
  keywords: (),
  AMS: (),
  lang: "en",
  translations: none,
  heading-color: rgb("#000000"),
  link-color: rgb("#000000"),
  lines: true,
  page-args: page-args,
  text-args-title: text-args-title,
  text-args-authors: text-args-authors,
  ncolumns: 1,
  equation-box-inline: true,
  equation-box-block: false,
  body,
) = {
  // Set the document's basic properties.
  set document(author: authors.map(a => a.name), title: title)
  set page(..page-args)
  set text(font: "New Computer Modern", lang: lang)
  set enum(numbering: "(i)")
  set outline(indent: 2em) // indent: auto does not work well with appendices
  show: great-theorems-init

  // Overrides the current translations
  if lang != none and translations != none {
    language-translations.update(value => {
      if lang in value {
        value.insert(lang, value.at(lang) + translations)
      } else {
        value.insert(lang, translations)
      }
      value
    })
  }

  // table label on top and not below the table
  show figure.where(kind: table): set figure.caption(position: top)

  // Heading settings.
  set heading(numbering: "1.1")
  show heading.where(level: 1): set text(size: 14pt, fill: heading-color)
  show heading.where(level: 2): set text(size: 12pt, fill: heading-color)

  // Equation settings.
  // Using i-figured:
  show heading: reset-counters
  show math.equation: show-equation.with(prefix: "eq:", only-labeled: true)

  // Using headcount:
  // show heading: reset-counter(counter(math.equation))
  // set math.equation(numbering: dependent-numbering("(1.1)"))
  set math.equation(supplement: none)

  show math.equation.where(block: false): x => {
    if equation-box-inline {
      box(x) // no line breaks in inline math
    } else {
      x
    }
  }
  show math.equation.where(block: true): x => {
    if equation-box-block {
      box(x)
    } else {
      x
    }
  }

  if lines {
    line(length: 100%, stroke: 2pt)
  }
  // Title row.
  if text-args-title.fill == auto {
    text-args-title.insert("fill", heading-color)
  }
  pad(
    bottom: 4pt,
    top: 4pt,
    align(center)[
      #block(text(..text-args-title, title))
      #v(1em, weak: true)
    ],
  )
  if lines {
    line(length: 100%, stroke: 2pt)
  }

  // Author information.
  // Format a single author: the name (with a superscript referring to the
  // affiliations and, if available, a link to the author's ORCID), followed by
  // the given affiliations and, if available, the author's email address.
  let format-author(author, affiliation-id: "", author-affiliations: ()) = align(center)[
    #let author-with-id = [#text(..text-args-authors, author.name)#super(to-string(affiliation-id))]
    #if author.keys().contains("orcid") {
      link("http://orcid.org/" + author.orcid)[
        #pad(
          bottom: -8pt,
          grid(
            columns: (8pt, auto, 8pt),
            rows: 10pt,
            [],
            author-with-id,
            [#pad(left: 4pt, top: -4pt, image("orcid.svg", width: 8pt))],
          ),
        )
      ]
    } else {
      grid(
        columns: auto,
        rows: 2pt,
        author-with-id,
      )
    }
    #for affiliation in author-affiliations {
      affiliation
      linebreak()
    }
    #if "email" in author {
      link("mailto:" + author.email)
    }
  ]

  let authors-grid = grid.with(
    columns: (1fr,) * calc.min(authors-per-row, authors.len()),
    gutter: 1.5em,
  )

  if authors-style == "shared" {
    // All affiliations are listed below the authors and are linked to the
    // authors by superscripts.
    pad(
      top: 0.5em,
      x: 2em,
      authors-grid(
        ..authors.map(author => format-author(
          author,
          affiliation-id: author.at("affiliation-id", default: ""),
        )),
      ),
    )

    // Affiliation information.
    pad(
      top: 0.5em,
      x: 2em,
      if affiliations != none {
        for affiliation in affiliations {
          align(center)[
            #super(to-string(affiliation.at("id", default: "")))#affiliation.name
          ]
        }
      },
    )
  } else if authors-style == "per-author" {
    // Every author is typeset in their own column together with their
    // affiliations, so no superscripts are needed.
    pad(
      top: 0.5em,
      x: 2em,
      authors-grid(
        ..authors.map(author => format-author(
          author,
          author-affiliations: affiliations-of(author, affiliations),
        )),
      ),
    )
  } else {
    panic("Unknown authors-style: " + authors-style + ". Use \"shared\" or \"per-author\".")
  }

  align(center)[#date]

  // Set the color for links and references after the authors to not overwrite the text color in the case of an available orcid.
  show link: set text(fill: link-color)
  show ref: set text(fill: link-color)

  // Abstract.
  if abstract != none {
    pad(
      x: 3em,
      top: 1em,
      bottom: 0.4em,
      align(center)[
        #heading(
          outlined: false,
          numbering: none,
          text(0.85em, smallcaps(get-language-title("abstract"))),
        )
        #set par(justify: true)
        #set text(hyphenate: false)

        #abstract
      ],
    )
  }

  // Keywords
  if keywords.len() > 0 {
    [*_#get-language-title("keywords")_*. #h(0.3cm)] + keywords.map(str).join(" · ")
    linebreak()
  }
  // AMS
  if AMS.len() > 0 {
    [*#get-language-title("ams")*. #h(0.3cm)] + AMS.map(str).join(", ")
  }
  // Main body.
  set par(justify: true)
  set text(hyphenate: false)

  columns(ncolumns)[
    #body
  ]
}

#let appendices(body) = {
  counter(heading).update(0)
  counter("appendices").update(1)

  set heading(
    numbering: (..nums) => {
      let vals = nums.pos()
      let value = "ABCDEFGHIJ".at(vals.at(0) - 1)
      if vals.len() == 1 {
        return get-language-title("appendix") + " " + value
      } else {
        return value + "." + nums.pos().slice(1).map(str).join(".")
      }
    },
  )
  [#colbreak() #body]
}
